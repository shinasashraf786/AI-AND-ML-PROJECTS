# imports - compatibility packages
from __future__ import absolute_import

# module imports
from bulbea.entity import Entity

class Stock(Entity):
    pass
