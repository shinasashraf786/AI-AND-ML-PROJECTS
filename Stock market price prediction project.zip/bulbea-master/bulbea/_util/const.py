ABSURL_QUANDL          = 'https://www.quandl.com'
QUANDL_MAX_DAILY_CALLS = 50000

SHARE_ACCEPTED_SAVE_FORMATS = ('csv', 'pkl')