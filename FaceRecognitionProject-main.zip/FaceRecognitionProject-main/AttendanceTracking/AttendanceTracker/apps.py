from django.apps import AppConfig

class AttendancetrackerConfig(AppConfig):
    name = 'AttendanceTracker'
