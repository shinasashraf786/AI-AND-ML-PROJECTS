# imports - compatibility packages
from __future__ import absolute_import

# module imports
from bulbea.app.server import app
