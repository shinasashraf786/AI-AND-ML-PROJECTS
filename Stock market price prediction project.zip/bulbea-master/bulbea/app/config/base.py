# imports - standard packages
from enum import Enum

class BaseConfig(object):
    class URL(object):
        BASE = "/"
