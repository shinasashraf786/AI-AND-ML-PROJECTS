Developer Interface
===================

Entities
++++++++

.. autoclass:: bulbea.Share
   :inherited-members:
.. autoclass:: bulbea.Stock
   :inherited-members:

Modelling
+++++++++
